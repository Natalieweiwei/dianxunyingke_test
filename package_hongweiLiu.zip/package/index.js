/**
 * Example problem with existing solution and passing test.
 * See problem 0 in the spec file for the assertion
 * @returns {string}
 */
exports.example = () => 'hello world';

exports.stripPrivateProperties = (properties, targetArray)=> {
    let stripArray = new Array();
    for(let targetObject of targetArray){
        for(let propertyKey of properties){
           delete targetObject[propertyKey];
        }
        stripArray.push(targetObject);  
    }
    return stripArray; 
};
exports.excludeByProperty = (excludeProperty, targetArray) => {
    let excluedArray = new Array();
    for(let targetObject of targetArray){
        if(!targetObject[excludeProperty]){
            excluedArray.push(targetObject); 
        }
    }
    return excluedArray;  
};
exports.sumDeep = (targetArray) => {
    let sumDeepArray = new Array();
    for(let targetObject of targetArray){
        for(let deepKey in targetObject){
            let targetSum = 0;
            let sumTemp = {};
            for(let sumObject of targetObject[deepKey]){
                for(let subKey in sumObject){
                    targetSum = targetSum + sumObject[subKey];
                }
            }
            sumTemp[deepKey]=targetSum;
            sumDeepArray.push(sumTemp); 
        }
    }
    return sumDeepArray;   
};
exports.applyStatusColor = (colorMappingObject, targetStatusList) => {
    let colorStatusList = new Array();
    for(let targetColorStatus of targetStatusList){
        for(let color in colorMappingObject){
            if(colorMappingObject[color].findIndex((n) => n === targetColorStatus.status)!==-1){
                targetColorStatus.color = color; 
                colorStatusList.push(targetColorStatus); 
                break;
            }
        }
    }
    return colorStatusList; 
};
exports.createGreeting = (greeting, content) => {
     var greet = (...rest) => greeting(content, rest[0]);
     return greet; 
};
exports.setDefaults = (defaultProperty) => {
     var greet = (...rest) => {
         let allProperty = rest[0];
         for(let propertyKey in defaultProperty){
             if(allProperty[propertyKey]=== undefined){
                allProperty = Object.assign(allProperty, defaultProperty); 
             }
         }
         return allProperty;
    };
    return  greet;
};
exports.fetchUserByNameAndUsersCompany = (userName, promises) => {
    return Promise.resolve(promises.fetchUsers()).then(function(users){
        for(let user of users){
            if(user.name === userName){
                return Promise.resolve(promises.fetchCompanyById(user.companyId)).then(function(campany){
                    return Promise.resolve(promises.fetchStatus()).then(function(status){
                        return {
                            company: campany,
                            status,
                            user: user,
                        };
                    }); 
                }); 
            }
        }
    });
};
